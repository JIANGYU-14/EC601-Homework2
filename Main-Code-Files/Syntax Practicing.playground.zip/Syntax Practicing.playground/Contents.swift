//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
let lable = "this is "
let width = "wjy"
let xx = lable + width
let zz = 3
let mm = 4
let ll = "i have \(zz+mm) apples"
let qq: Int? = 999
var list = ["good","bad"]
list[1] = "ok"
list
let number = 23
if number > 100{
    print("the number bigger than 100")
} else {
    print("small")
}
let array = [1,2,3,4,5]
var total = 0
for i in array{
    if i > 3{
        total += 1
    }
    else {
        total += 0
    }
}
print(total)
var namess: String? = "777ds"
var greeting = "Hello!"
if var name = namess{
    greeting = "Hello!, \(name)"
}
var fruit = "banana"
var xxx = Int(fruit)
print(xxx)

let vegeiess = "abc def"
switch vegeiess{
    case "123456":
    print("that is")
    case "1234":
    print("not")
case let a where a.hasSuffix("f"):
    print("this is the one")
default:
    print("mmmmmmm")
}
var looptest = 0
for i in 0..<4{
    looptest += 1
}
print(looptest)
for m in 0...4{
    looptest += 1
}
print(looptest)
func functiona(name:String, day:String) -> String{
    return "Hello \(name),today is \(day)"
}
functiona("WJY", day: "Monday")
var arraay = ["aa","bb","cc"]
arraay.insert("dd",atIndex: 2)
arraay
// Classes and Initializers
class shape {
    var numberOfSides = 0
    func simpleDescription() -> String{
        return "A shape with \(numberOfSides) sides"
    }
}
var xxxxx = shape()
xxxxx.numberOfSides = 7
var xdescription = xxxxx.simpleDescription()

class NamedShape {
    var numberOfSides = 0
    var name : String
    init (name:String){
        self.name = name
    }
    func simpleDescription() -> String{
        return "A shape with \(numberOfSides) Sides"
    }
}

let namedShape = NamedShape(name: "my named shape")
namedShape.simpleDescription()

class square : NamedShape{
    var sidelength : Double
    init (sidelength:Double, name:String){
        self.sidelength = sidelength
        super.init (name: name)
        numberOfSides = 4
    }
    func area() -> Double{
        return sidelength * sidelength
    }
     override func simpleDescription() -> String {
        return "A shape with sides of length \(sidelength)"
    }
}

let testsquare = square(sidelength: 5.4, name: "my test square")
testsquare.area()
testsquare.simpleDescription()

class circle: NamedShape{
    var radius : Double
    init?(radius:Double, name: String){
        self.radius = radius
        super.init(name: name)
        numberOfSides = 1
        if radius <= 0{
            return nil
        }
    }
}
let successfulcircle = circle(radius: 4.2, name: "yes")
let failedcircle = circle(radius: -9, name: "no")

class triangle: NamedShape{
    init(sidelength: Double, name: String){
        super.init(name: name)
        numberOfSides = 3
    }
}

let shapesarray = [triangle(sidelength: 1.5, name: "t1"),triangle(sidelength: 2.3, name: "t2"),square(sidelength: 2.7, name: "s1")]
var squares = 0
var triangles = 0
for shape in shapesarray{
    if let square = shape as? square{
        squares++
    }else if let triangle = shape as? triangle{
        triangles++
    }
}
print("\(squares) squares and \(triangles) triangles")

// Enumerations and Structions


